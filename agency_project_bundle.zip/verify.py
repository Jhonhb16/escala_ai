import os
import sys

# Ensure app is in path
sys.path.append(os.getcwd())

from app.main import create_graph
from langchain_core.messages import HumanMessage
from dotenv import load_dotenv

load_dotenv()

# Set dummy key for verification if not present
if not os.getenv("OPENAI_API_KEY"):
    os.environ["OPENAI_API_KEY"] = "sk-mock-key-for-testing"

from unittest.mock import MagicMock, patch

def run_test():
    print("Running Verification Test...")
    
    # Mock ChatOpenAI to avoid API Key errors during verification
    with patch('app.agents.supervisor.ChatOpenAI') as MockSupervisorLLM, \
         patch('app.agents.prospector.ChatOpenAI') as MockProspectorLLM, \
         patch('app.agents.outreach.ChatOpenAI') as MockOutreachLLM, \
         patch('app.agents.proposal.ChatOpenAI') as MockProposalLLM:
         
        # Configure Mock Schema for Supervisor
        # Supervisor returns a function call "route" with argument "next"
        mock_supervisor_instance = MockSupervisorLLM.return_value
        # We need to mock the chain invoke. 
        # The chain in Supervisor is: prompt | llm.bind_functions | JsonOutputFunctionsParser
        # It's easier to mock the `SupervisorAgent.invoke` method directly if we want to bypass the chain,
        # but let's try to mock the LLM response first.
        # Actually, mocking the entire Agent invocation is safer for a smoke test of the GRAPH.
        
        pass

    # Better approach: Mock the Agents' invoke methods to return deterministic routing
    with patch('app.agents.supervisor.SupervisorAgent.invoke') as mock_supervisor_invoke, \
         patch('app.agents.prospector.ProspectorAgent.invoke') as mock_prospector_invoke, \
         patch('app.agents.outreach.OutreachAgent.invoke') as mock_outreach_invoke:
         
        # Defines the flow: Supervisor -> Prospector -> Supervisor -> Outreach -> Supervisor -> FINISH
        
        # 1. Supervisor sends to Prospector
        mock_supervisor_invoke.side_effect = [
            {"next": "Prospector", "messages": ["Supervisor: Go search."]},
            {"next": "Outreach", "messages": ["Supervisor: Lead found, send email."]},
            {"next": "FINISH", "messages": ["Supervisor: Job done."]}
        ]
        
        # 2. Prospector finds a lead
        mock_prospector_invoke.return_value = {
            "current_lead": {"id": "123", "name": "Mock Clinic", "status": "QUALIFIED", "score": 90, "services": ["Botox"], "notes": ""},
            "messages": ["Prospector: Found Mock Clinic."]
        }
        
        # 3. Outreach sends email
        mock_outreach_invoke.return_value = {
             "messages": ["Outreach: Email sent."],
             "current_lead": {"id": "123", "name": "Mock Clinic", "status": "CONTACTED", "score": 90, "services": ["Botox"], "notes": "Email Sent"}
        }

        initial_state = {
            "messages": [HumanMessage(content="Find a lead, score it, and if qualified, send an email.")],
            "leads_queue": [],
            "metrics": {"emails_sent_today": 0, "tokens_used": 0, "leads_processed": 0},
            "errors": []
        }

        print("Graph compiled. Starting stream (MOCKED)...")
        with open("verify.log", "w") as log_file:
            try:
                app = create_graph() # Create graph inside the patch context? No, classes are already imported.
                # But instances are created inside node functions.
                # agent_node calls AgentFactory.create which creates instances.
                # So patching the classes or invoke methods should work if done correctly.
                # Since SupervisorAgent is instantiated inside supervisor_node, patching SupervisorAgent.invoke works.
                
                step_count = 0
                for event in app.stream(initial_state):
                    step_count += 1
                    for k, v in event.items():
                        if k != "__end__":
                            msg = f"[{k}] Step Finished.\n"
                            print(msg.strip())
                            log_file.write(msg)
                            if "next" in v:
                                msg = f"  > Decision: {v['next']}\n"
                                print(msg.strip())
                                log_file.write(msg)
                            if "current_lead" in v and v.get("current_lead"):
                                lead = v["current_lead"]
                                msg = f"  > Lead: {lead['name']} | Status: {lead['status']}\n"
                                print(msg.strip())
                                log_file.write(msg)
                    
                    if step_count > 10:
                        msg = "Force stopping after 10 steps.\n"
                        print(msg.strip())
                        log_file.write(msg)
                        break
                        
                msg = "Test Completed Successfully (MOCKED).\n"
                print(msg.strip())
                log_file.write(msg)
                
            except Exception as e:
                msg = f"Test Failed with Error: {e}\n"
                print(msg.strip())
                log_file.write(msg)
                import traceback
                traceback.print_exc(file=log_file)

if __name__ == "__main__":
    run_test()
