# Guía de Despliegue en VPS Hostinger

Esta guía explica cómo subir los archivos de tu proyecto "AI Marketing Agency" a tu servidor VPS de Hostinger.

## Requisitos Previos

Necesitas tener a mano los datos de acceso de tu VPS (enviados por Hostinger al correo o disponibles en el panel de control):
1.  **Dirección IP** (ej. `123.456.78.90`)
2.  **Usuario** (usualmente `root`)
3.  **Contraseña** (o clave SSH)

---

## Método 1: Usando la Terminal (SCP) - Recomendado

Este método es rápido y no requiere instalar programas adicionales si usas Windows 10/11.

1.  Abre una terminal (PowerShell o CMD) en la carpeta de tu proyecto en tu PC.
2.  Ejecuta el siguiente comando (Reemplaza `TU_IP` con la IP real de tu VPS):

    ```powershell
    # Copia todo el contenido de la carpeta actual al VPS
    scp -r . root@TU_IP:/opt/agency-ai/app
    ```

3.  Te pedirá confirmar la conexión (escribe `yes`) y luego tu **contraseña** del VPS.
4.  Espera a que termine la copia.

---

## Método 2: Usando FileZilla (Visual)

Si prefieres una interfaz gráfica para arrastrar y soltar archivos.

1.  Descarga e instala [FileZilla Client](https://filezilla-project.org/).
2.  Abre FileZilla y configura la conexión:
    *   **Servidor/Host**: `sftp://TU_IP` (importante poner `sftp://`)
    *   **Usuario**: `root`
    *   **Contraseña**: Tu contraseña del VPS
    *   **Puerto**: 22
3.  Haz clic en **Conexión Rápida**.
4.  En el lado **Derecho (Sitio Remoto)**, navega a la carpeta `/opt/agency-ai/app` (créala si no existe).
5.  En el lado **Izquierdo (Sitio Local)**, busca la carpeta de tu proyecto.
6.  Selecciona todos los archivos del lado izquierdo y arrástralos al derecho.

---

## Método 3: Usando Git (Mejor Práctica)

Si ya usas Git, este método facilita las actualizaciones futuras.

1.  **En tu PC**: Asegúrate de que tu código está en un repositorio (GitHub/GitLab).
2.  **En el VPS**:
    *   Conéctate por SSH: `ssh root@TU_IP`
    *   Clona el repositorio:
        ```bash
        git clone https://github.com/TU_USUARIO/TU_REPO.git /opt/agency-ai/app
        ```

---

## Pasos Finales (En el VPS)

Una vez subidos los archivos, conéctate a tu VPS para iniciar el sistema.

1.  **Conectar por SSH**:
     Abre tu terminal en Windows y escribe:
    ```powershell
    ssh root@TU_IP
    ```

2.  **Ejecutar Script de Instalación**:
    ```bash
    cd /opt/agency-ai/app
    chmod +x scripts/setup_vps.sh
    ./scripts/setup_vps.sh
    ```

3.  **Configurar Variables de Entorno**:
    ```bash
    cp .env.example .env
    nano .env
    # (Pega tus claves reales aquí, guarda con Ctrl+O y sal con Ctrl+X)
    ```

4.  **Iniciar Docker**:
    ```bash
    docker compose up -d --build
    ```

¡Listo! Tu agencia estará corriendo en tu IP.
