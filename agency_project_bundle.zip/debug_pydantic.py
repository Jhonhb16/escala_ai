import sys
import os

print(f"Python Executable: {sys.executable}")
print(f"Sys Path: {sys.path}")

try:
    import pydantic
    print(f"Pydantic Version: {pydantic.VERSION}")
    print(f"Pydantic File: {pydantic.__file__}")
except Exception as e:
    print(f"Error importing pydantic: {e}")

try:
    from pydantic.v1.fields import FieldInfo
    print("Success: from pydantic.v1.fields import FieldInfo")
except ImportError as e:
    print(f"Failed (fields): {e}")

try:
    from pydantic.v1.field import FieldInfo
    print("Success: from pydantic.v1.field import FieldInfo")
except ImportError as e:
    print(f"Failed (field): {e}")

try:
    import langchain_core
    print(f"LangChain Core Version: {langchain_core.__version__}")
    print(f"LangChain Core File: {langchain_core.__file__}")
except Exception as e:
    print(f"Error importing langchain_core: {e}")
