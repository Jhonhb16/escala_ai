# AI Marketing Agency

A multi-tenant, AI-powered marketing agency system designed for medical clinics. Features autonomous agents for prospecting, outreach, and strategy generation.

## Features
- **Base Team**: Prospecting (Apollo), Outreach (Gemini), QA (Medical Compliance).
- **Client Team**: Strategy, Funnel, and Creative generation per workspace.
- **Multi-tenancy**: Data isolation by workspace.
- **Integrations**: Instantly, HubSpot, Cal.com, Apollo.io.

## Setup

### Prerequisites
- Python 3.11+
- Docker & Docker Compose

### Installation
1. Clone repository.
2. Create virtual environment:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Linux/Mac
   .venv\Scripts\activate     # Windows
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Configure Environment:
   Copy `.env.example` to `.env` and fill in API keys.

### Database
Start Postgres with pgvector:
```bash
docker-compose up -d db
```

### Running the App
```bash
uvicorn app.main:app --reload
```
API Info: http://localhost:8000/docs

## CLI Operations
The system is primarily operated via CLI.

**1. Create Workspace**
```bash
python scripts/cli.py create-workspace "ClinicName"
```

**2. Run Outreach (End-to-End)**
```bash
python scripts/cli.py run-outreach <workspace_id>
```

**3. Verify Integrations**
```bash
python scripts/verify_integrations.py
```

## Architecture
- **Agents**: Built with LangGraph.
- **Backend**: FastAPI.
- **DB**: SQLAlchemy + AsyncPG.
