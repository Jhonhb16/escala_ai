EMAIL_TEMPLATES = {
    "cold_outreach": "Hi {name}, ..."
}
