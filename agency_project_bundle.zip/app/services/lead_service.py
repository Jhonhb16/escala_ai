from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from app.db.models import Lead
from typing import List, Optional

class LeadService:
    def __init__(self, session: AsyncSession, workspace_id: int):
        self.session = session
        self.workspace_id = workspace_id

    async def add_lead(self, data: dict) -> Lead:
        lead = Lead(
            workspace_id=self.workspace_id,
            **data
        )
        self.session.add(lead)
        # We don't commit here usually to allow batching, but for simplicity:
        await self.session.commit()
        await self.session.refresh(lead)
        return lead

    async def get_pending_leads(self, limit: int = 10) -> List[Lead]:
        """Get leads that are NEW and have not been contacted."""
        query = select(Lead).where(
            Lead.workspace_id == self.workspace_id,
            Lead.status == "NEW"
        ).limit(limit)
        
        result = await self.session.execute(query)
        return result.scalars().all()

    async def update_status(self, lead_id: int, status: str, quality_score: int = None):
        values = {"status": status}
        if quality_score is not None:
            values["quality_score"] = quality_score
            
        stmt = update(Lead).where(
            Lead.id == lead_id,
            Lead.workspace_id == self.workspace_id
        ).values(**values)
        
        await self.session.execute(stmt)
        await self.session.commit()
