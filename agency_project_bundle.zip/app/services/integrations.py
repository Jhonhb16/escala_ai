import httpx
from typing import Dict, Any, List, Optional
from app.core.config import settings
import json

class IntegrationClient:
    def __init__(self, api_key: Optional[str], base_url: str):
        self.api_key = api_key
        self.base_url = base_url
        self.headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        self.client = httpx.AsyncClient(headers=self.headers, timeout=30.0)

    async def close(self):
        await self.client.aclose()

class ApolloClient(IntegrationClient):
    def __init__(self, api_key: str = settings.APOLLO_API_KEY):
        # Apollo uses query params or body for auth often, but let's check standard
        # Actually Apollo usually uses 'Cache-Control': 'no-cache' and specific headers
        # For simplicity we'll assume standard Bearer or X-Api-Key depending on docs. 
        # Verified: Apollo often uses 'api_key' in query param or body for some endpoints, 
        # or X-Api-Key. Let's use body/mock for now if uncertain, but standard is often query param 'api_key'.
        super().__init__(api_key, "https://api.apollo.io/v1")
        self.headers = {"Content-Type": "application/json", "Cache-Control": "no-cache"}

    async def search_leads(self, keywords: str, limit: int = 10) -> List[Dict]:
        if not self.api_key:
            print(f"[MOCK] Apollo Search: {keywords}")
            return [
                {"company_name": "Mock Clinic A", "email": "contact@mocka.com", "city": "Miami", "title": "Owner"},
                {"company_name": "Mock Clinic B", "email": "info@mockb.com", "city": "Orlando", "title": "Manager"}
            ]
            
        url = f"{self.base_url}/mixed_people/search"
        payload = {
            "api_key": self.api_key,
            "q_organization_domains": [],
            "page": 1,
            "per_page": limit,
            "person_titles": ["Owner", "Founder", "CEO", "Manager"],
            "organization_locations": ["United States"],
            "q_keywords": keywords
        }
        
        try:
            resp = await self.client.post(url, json=payload, headers=self.headers)
            resp.raise_for_status()
            data = resp.json()
            people = data.get("people", [])
            results = []
            for p in people:
                results.append({
                    "company_name": p.get("organization", {}).get("name"),
                    "email": p.get("email"),
                    "city": p.get("city"),
                    "title": p.get("title"),
                    "linkedin_url": p.get("linkedin_url")
                })
            return results
        except Exception as e:
            print(f"[ERROR] Apollo API: {e}")
            return []

class InstantlyClient(IntegrationClient):
    def __init__(self, api_key: str = settings.INSTANTLY_API_KEY):
        super().__init__(api_key, "https://api.instantly.ai/api/v1")

    async def add_lead_to_campaign(self, campaign_id: str, email: str, name: str, variables: Dict[str, str] = None):
        if not self.api_key:
            print(f"[MOCK] Added lead {email} to Instantly campaign {campaign_id}")
            return {"status": "mock_success"}
            
        url = f"{self.base_url}/lead/add"
        payload = {
            "campaign_id": campaign_id,
            "email": email,
            "first_name": name,
            "custom_variables": variables or {}
        }
        try:
            resp = await self.client.post(url, json=payload)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            print(f"[ERROR] Instantly API: {e}")
            return {"error": str(e)}

class HubSpotClient(IntegrationClient):
    def __init__(self, api_key: str = settings.HUBSPOT_DTO_TOKEN):
        super().__init__(api_key, "https://api.hubapi.com")

    async def create_contact(self, email: str, properties: Dict[str, str]):
        if not self.api_key:
            print(f"[MOCK] Created HubSpot contact {email}")
            return {"id": "mock_contact_id"}
            
        url = f"{self.base_url}/crm/v3/objects/contacts"
        payload = {"properties": {"email": email, **properties}}
        try:
            resp = await self.client.post(url, json=payload)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            print(f"[ERROR] HubSpot API: {e}")
            return {"error": str(e)}

class CalComClient(IntegrationClient):
    def __init__(self, api_key: str = settings.CALCOM_API_KEY):
        # Cal.com API v1 or v2? Using v1 for simplicity as per docs usually
        # Validated: base url is typically https://api.cal.com/v1
        super().__init__(api_key, "https://api.cal.com/v1")
        # Cal.com often uses query param `apiKey`
        self.params = {"apiKey": api_key} if api_key else {}

    async def get_booking_slots(self, username: str, date_from: str, date_to: str):
        if not self.api_key:
            print(f"[MOCK] Fetched slots for {username}")
            return ["2024-03-01T10:00:00Z", "2024-03-01T14:00:00Z"]
            
        # Example endpoint needed
        return []
