from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.models import Workspace
from typing import Dict, Any

class WorkspaceService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create_workspace(self, name: str, settings: Dict[str, Any] = None) -> Workspace:
        if settings is None:
            settings = {
                "daily_email_limit": 50,
                "banned_words": ["cure", "guarantee", "instant results", "100%"]
            }
            
        workspace = Workspace(name=name, settings=settings)
        self.session.add(workspace)
        await self.session.commit()
        await self.session.refresh(workspace)
        return workspace

    async def get_workspace_by_name(self, name: str) -> Workspace | None:
        result = await self.session.execute(select(Workspace).where(Workspace.name == name))
        return result.scalars().first()

    async def get_workspace(self, id: int) -> Workspace | None:
        result = await self.session.execute(select(Workspace).where(Workspace.id == id))
        return result.scalars().first()
