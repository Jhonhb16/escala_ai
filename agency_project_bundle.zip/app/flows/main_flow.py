from typing import Annotated, Any, Dict, List, Literal, Optional
from langgraph.graph import StateGraph, END
import logging
from app.core.state import AgentState
from app.agents.supervisor import SupervisorAgent
from app.agents.factory import AgentFactory

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def agent_node(state: AgentState, agent_name: str):
    logger.info(f"Node: {agent_name} invoked")
    
    # Instantiate the agent
    agent = AgentFactory.create(agent_name)
    
    # Run logic
    result = agent.invoke(state)
    return result

def supervisor_node(state: AgentState):
    logger.info("Node: Supervisor invoked")
    
    # Get all potential workers
    members = AgentFactory.list_agents()
    
    # Supervisor logic
    supervisor = SupervisorAgent(members)
    result = supervisor.invoke(state)
    return result

def create_flow():
    workflow = StateGraph(AgentState)
    
    # Identify workers
    members = AgentFactory.list_agents()
    
    # Add Supervisor node
    workflow.add_node("Supervisor", supervisor_node)
    
    # Add Worker nodes
    for member in members:
        workflow.add_node(member, lambda state, name=member: agent_node(state, name))

    # Add Edges
    for member in members:
        workflow.add_edge(member, "Supervisor")

    # Conditional logic
    conditional_map = {k: k for k in members}
    conditional_map["FINISH"] = END
    
    workflow.add_conditional_edges(
        "Supervisor",
        lambda x: x["next"],
        conditional_map
    )
    
    workflow.set_entry_point("Supervisor")
    
    return workflow.compile()
