from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    PROJECT_NAME: str = "AI Marketing Agency"
    API_V1_STR: str = "/api/v1"
    
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://postgres:password@localhost:5432/agency_db"
    
    # Security / Keys
    OPENAI_API_KEY: Optional[str] = None
    GEMINI_API_KEY: Optional[str] = None
    
    INSTANTLY_API_KEY: Optional[str] = None
    CALCOM_API_KEY: Optional[str] = None
    HUBSPOT_DTO_TOKEN: Optional[str] = None
    APOLLO_API_KEY: Optional[str] = None
    
    # App Config
    ENVIRONMENT: str = "development"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
