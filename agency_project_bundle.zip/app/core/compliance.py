from typing import List, Tuple

class ComplianceEngine:
    BANNED_WORDS = [
        "cure", "curar", "guarantee", "garantizado", 
        "instant results", "resultados instantáneos",
        "100%", "permanent", "permanente", "miracle", "milagro",
        "doctor approved", "fda approved" 
    ]
    
    RISKY_PHRASES = [
        "best in", "cheapest", "fastest", "pain free", "sin dolor"
    ]

    @staticmethod
    def check_text(text: str) -> Tuple[bool, List[str], str]:
        """
        Validates text against compliance rules.
        Returns: (passed: bool, issues: List[str], corrected_suggestion: str)
        """
        text_lower = text.lower()
        issues = []
        
        for word in ComplianceEngine.BANNED_WORDS:
            if word in text_lower:
                issues.append(f"Contains banned word: '{word}'")
                
        for phrase in ComplianceEngine.RISKY_PHRASES:
            if phrase in text_lower:
                issues.append(f"Contains risky phrase: '{phrase}'")
                
        if issues:
            return False, issues, "Please remove medical claims and guarantees."
            
        return True, [], text
