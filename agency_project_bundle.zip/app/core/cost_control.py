from app.core.config import Config
from app.core.state import AgentState

class CostControl:
    @staticmethod
    def check_limits(state: AgentState) -> bool:
        """
        Returns True if limits are within bounds.
        Returns False if limits are exceeded.
        """
        metrics = state.get("metrics", {})
        
        emails_sent = metrics.get("emails_sent_today", 0)
        tokens_used = metrics.get("tokens_used", 0)
        
        leads_processed = metrics.get("leads_processed", 0)
        
        if emails_sent >= Config.MAX_DAILY_EMAILS:
            return False
            
        if tokens_used >= Config.MAX_TOKENS_PER_RUN:
            return False

        if leads_processed >= Config.MAX_LEADS_PER_DAY:
            return False

        if emails_sent >= Config.MAX_EMAILS_PER_INBOX:
            return False
            
        return True

    @staticmethod
    def update_metrics(state: AgentState, tokens: int = 0, emails: int = 0) -> AgentState:
        metrics = state.get("metrics", {})
        metrics["tokens_used"] = metrics.get("tokens_used", 0) + tokens
        metrics["emails_sent_today"] = metrics.get("emails_sent_today", 0) + emails
        state["metrics"] = metrics
        return state
