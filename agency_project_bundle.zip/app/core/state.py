from typing import TypedDict, Annotated, List, Dict, Any, Optional
from langchain_core.messages import BaseMessage
import operator

class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], operator.add]
    next: str
    
    # Context data
    workspace_id: int
    current_lead_id: Optional[int]
    
    # Task specific data
    task_status: str
    errors: List[str]
    
    # Shared memory for agents
    shared_data: Dict[str, Any]
    metrics: Dict[str, Any]
