from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI
from app.core.config import settings

def get_llm(temperature: float = 0.7):
    """
    Returns the configured LLM instance.
    Prioritizes Gemini if key is present, otherwise falls back to OpenAI (or error).
    """
    if settings.GEMINI_API_KEY:
        return ChatGoogleGenerativeAI(
            model="gemini-pro",
            google_api_key=settings.GEMINI_API_KEY,
            temperature=temperature,
            convert_system_message_to_human=True # Sometimes needed for older langchain versions
        )
    elif settings.OPENAI_API_KEY:
        return ChatOpenAI(
            model="gpt-3.5-turbo",
            api_key=settings.OPENAI_API_KEY,
            temperature=temperature
        )
    else:
        # Fallback dump mock or error
        raise ValueError("No LLM API Key found (OPENAI_API_KEY or GEMINI_API_KEY)")
