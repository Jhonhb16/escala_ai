import sys
from loguru import logger
from rich.logging import RichHandler

# Configure Loguru to use RichHandler for pretty console output
logger.configure(
    handlers=[
        {"sink": RichHandler(rich_tracebacks=True), "format": "{message}"},
        {"sink": "app.log", "serialize": True, "rotation": "10 MB"},
    ]
)

def get_logger(name: str):
    return logger.bind(name=name)
