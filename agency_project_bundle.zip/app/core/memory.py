from typing import Any, Dict, List
import json
import os
from .config import Config

class BaseMemory:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self._load()

    def _load(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, 'r') as f:
                self.data = json.load(f)
        else:
            self.data = {}

    def _save(self):
        with open(self.file_path, 'w') as f:
            json.dump(self.data, f, indent=2)

    def get(self, key: str) -> Any:
        return self.data.get(key)

    def set(self, key: str, value: Any):
        self.data[key] = value
        self._save()

class GlobalMemory(BaseMemory):
    """Stores broad patterns and optimization signals."""
    def __init__(self):
        super().__init__(os.path.join(Config.OUTPUT_DIR, 'global_memory.json'))

class LeadMemory(BaseMemory):
    """Stores specific interactions and data for leads."""
    def __init__(self):
        super().__init__(os.path.join(Config.OUTPUT_DIR, 'lead_memory.json'))

class PerformanceMemory(BaseMemory):
    """Stores metrics and success rates."""
    def __init__(self):
        super().__init__(os.path.join(Config.OUTPUT_DIR, 'performance_memory.json'))

# Singleton instances
global_memory = GlobalMemory()
lead_memory = LeadMemory()
performance_memory = PerformanceMemory()
