import os
import json
import time
from typing import Any, Dict, List, Optional, Union
from openai import OpenAI, OpenAIError
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from app.core.config import Config
from app.core.logger import get_logger

logger = get_logger("OpenAIClient")

class OpenAIClient:
    def __init__(self):
        self.api_key = Config.OPENAI_API_KEY
        self.model = Config.MODEL_NAME
        self.cost_file = os.path.join(Config.OUTPUT_DIR, "usage_cost.json")
        
        # Simple pricing map (approximate)
        self.pricing = {
            "gpt-4-turbo": {"input": 10.00, "output": 30.00}, # per 1M tokens
            "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
            "gpt-4o": {"input": 5.00, "output": 15.00}
        }

        if Config.USE_MOCK_DATA:
            logger.warning("Running in MOCK MODE. No real API calls will be made.")
            self.client = None
        else:
            if not self.api_key:
                 logger.warning("OPENAI_API_KEY not found. Client will fail if used.")
            else:
                 self.client = OpenAI(api_key=self.api_key)

    def _track_cost(self, usage: Any, model: str):
        if not usage:
            return

        input_tokens = usage.prompt_tokens
        output_tokens = usage.completion_tokens
        
        # Determine price per 1M
        price_map = self.pricing.get(model, self.pricing["gpt-4-turbo"])
        cost = (input_tokens * price_map["input"] / 1_000_000) + (output_tokens * price_map["output"] / 1_000_000)
        
        # Load existing
        data = {}
        if os.path.exists(self.cost_file):
            with open(self.cost_file, "r") as f:
                try:
                    data = json.load(f)
                except:
                    pass
        
        today = time.strftime("%Y-%m-%d")
        if today not in data:
            data[today] = {"tokens": 0, "cost": 0.0}
            
        data[today]["tokens"] += (input_tokens + output_tokens)
        data[today]["cost"] += cost
        
        with open(self.cost_file, "w") as f:
            json.dump(data, f, indent=2)
            
        logger.info(f"Usage: {input_tokens} in / {output_tokens} out | Cost: ${cost:.5f}")

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        retry=retry_if_exception_type(OpenAIError)
    )
    def chat_completion(self, messages: List[Dict[str, str]], json_mode: bool = False) -> str:
        """
        Wrapper for Chat Completion.
        """
        if Config.USE_MOCK_DATA:
            logger.info("MOCKED OpenAI Call")
            
            # Simple keyword matching to simulate different agents
            content_str = str(messages)
            
            if "Score the lead" in content_str:
                return json.dumps({"score": 88})
                
            elif "Review this text" in content_str: # Compliance
                return json.dumps({"approved": True, "reason": "Safe"})
                
            elif "Decide who acts next" in content_str: # Supervisor
                # Simple round robin simulation based on history length or random
                # If history is short, Prospect. If we have a lead, Outreach.
                # In the mock flow, Prospector always finds a lead.
                # So Supervisor should route: Prospector -> Outreach -> Setter -> FINISH (or back to Prospector)
                
                # To prevent infinite loop in simple mock, let's just Randomize or check history
                import random
                if "Prospector: Found" in content_str:
                    return json.dumps({"next": "Outreach"})
                elif "Outreach: Email Sent" in content_str:
                    return json.dumps({"next": "FINISH"}) # End lead cycle
                else:
                    return json.dumps({"next": "Prospector"})

            elif "Write a short" in content_str: # Outreach
                return "Hi there, we noticed you offer Botox. Let's chat."
                
            elif "Create a proposal" in content_str: # Proposal
                return "Executive Summary: We will grow your clinic."

            return json.dumps({"score": 85, "approved": True, "reason": "Default Mock", "next": "FINISH"})

        params = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.7,
        }
        if json_mode:
            params["response_format"] = {"type": "json_object"}

        try:
            response = self.client.chat.completions.create(**params)
            self._track_cost(response.usage, self.model)
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI Call Failed: {e}")
            raise e
