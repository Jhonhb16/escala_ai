from typing import Dict, Any
from app.core.logger import get_logger

logger = get_logger("EmailPlatform")

class EmailPlatform:
    def __init__(self):
        pass

    def send_email(self, to_email: str, subject: str, body: str) -> bool:
        """
        Mock sending an email via Instantly/Gmail.
        """
        logger.info(f"SENDING EMAIL to {to_email} | Subject: {subject}")
        # In production, this would make an API call to Instantly.ai
        return True

    def check_replies(self) -> List[Dict[str, Any]]:
        """
        Mock checking for replies.
        """
        logger.info("Checking for new replies...")
        return []
