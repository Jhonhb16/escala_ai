from typing import List, Dict
import uuid
import random
import csv
import os
from app.core.state import Lead
from app.core.logger import get_logger
from app.core.config import Config

logger = get_logger("LeadSources")

class LeadSource:
    def __init__(self):
        pass

    def fetch_leads(self, count: int = 10) -> List[Lead]:
        """
        Fetch leads from CSV if configured, otherwise generate mock leads.
        """
        # Check if we should use CSV
        if not Config.USE_MOCK_DATA:
            csv_path = Config.LEADS_CSV_PATH
            if os.path.exists(csv_path):
                logger.info(f"Fetching leads from CSV: {csv_path}")
                return self._fetch_from_csv(csv_path, count)
            else:
                logger.warning(f"USE_MOCK_DATA=False but CSV not found at {csv_path}. Falling back to mock data.")

        logger.info(f"Fetching {count} mock leads...")
        leads = []
        for _ in range(count):
            leads.append(self._generate_mock_lead())
        return leads

    def _fetch_from_csv(self, file_path: str, count: int) -> List[Lead]:
        leads = []
        try:
            with open(file_path, mode='r', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                rows = list(reader)
                
                # In a real scenario, you might want to track which lines were processed.
                # For this implementation, we just take the first 'count' rows.
                target_rows = rows[:count]
                
                for row in target_rows:
                    services_str = row.get("services", "")
                    # Simple comma split for services
                    services_list = [s.strip() for s in services_str.split(",")] if services_str else []
                    
                    # Construct location from city/state
                    city = row.get("city", "")
                    state = row.get("state", "")
                    location = f"{city}, {state}" if city and state else (city or state or "")

                    lead = Lead(
                        id=str(uuid.uuid4()),
                        name=row.get("clinic_name", "Unknown"),
                        website=row.get("website", ""),
                        email=row.get("email", ""),
                        phone=row.get("phone", ""),  # CSV might not have phone yet, that's okay
                        location=location,
                        services=services_list,
                        instagram=row.get("instagram", ""),
                        score=0,
                        status="NEW",
                        notes=row.get("notes", "")
                    )
                    leads.append(lead)
            
            logger.info(f"Successfully loaded {len(leads)} leads from CSV.")
            return leads

        except Exception as e:
            logger.error(f"Failed to read CSV lead source: {e}")
            return []

    def _generate_mock_lead(self) -> Lead:
        cities = ["Miami, FL", "New York, NY", "Los Angeles, CA", "Austin, TX"]
        services_list = ["Botox", "Fillers", "Laser", "Facials", "CoolSculpting"]
        
        name = f"Clinic {uuid.uuid4().hex[:6]}"
        
        return Lead(
            id=str(uuid.uuid4()),
            name=name,
            website=f"https://{name.lower().replace(' ', '')}.com",
            email=f"contact@{name.lower().replace(' ', '')}.com",
            phone="555-0199",
            location=random.choice(cities),
            services=random.sample(services_list, k=2),
            instagram=f"@{name.lower().replace(' ', '_')}",
            score=0,
            status="NEW",
            notes=""
        )
