from app.tools.openai_client import OpenAIClient
from app.core.logger import get_logger

logger = get_logger("Compliance")

class ComplianceGate:
    def __init__(self):
        self.client = OpenAIClient()

    def review_content(self, content: str, context: str = "Cold Email") -> bool:
        """
        Reviews content for medical compliance and safety.
        Returns True if safe, False if unsafe.
        """
        logger.info(f"Reviewing {context} content...")
        
        prompt = [
            {"role": "system", "content": "You are a strict compliance officer for an esthetic clinic marketing agency. "
                                          "Reject any content that makes medical guarantees (e.g. 'Guaranteed results'), "
                                          "false claims, or is aggressive. "
                                          "Return JSON: {\"approved\": bool, \"reason\": str}"},
            {"role": "user", "content": f"Review this text:\n\n{content}"}
        ]
        
        try:
            response_json = self.client.chat_completion(prompt, json_mode=True)
            import json
            result = json.loads(response_json)
            
            if result["approved"]:
                logger.info("Content APPROVED.")
                return True
            else:
                logger.warning(f"Content REJECTED: {result.get('reason')}")
                return False
                
        except Exception as e:
            logger.error(f"Compliance check failed: {e}")
            # Fail safe is to reject if we can't verify
            return False
