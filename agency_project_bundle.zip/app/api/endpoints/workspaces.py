from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.services.workspace_service import WorkspaceService
from pydantic import BaseModel

router = APIRouter()

class WorkspaceCreate(BaseModel):
    name: str

@router.post("/")
async def create_workspace(workspace: WorkspaceCreate, db: AsyncSession = Depends(get_db)):
    service = WorkspaceService(db)
    existing = await service.get_workspace_by_name(workspace.name)
    if existing:
        raise HTTPException(status_code=400, detail="Workspace already exists")
    
    return await service.create_workspace(name=workspace.name)
