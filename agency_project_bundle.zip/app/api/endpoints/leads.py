from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.services.lead_service import LeadService
from pydantic import BaseModel
from typing import Optional

router = APIRouter()

class LeadCreate(BaseModel):
    name: str
    email: str
    company_name: str
    city: str

@router.post("/{workspace_id}")
async def create_lead(workspace_id: int, lead: LeadCreate, db: AsyncSession = Depends(get_db)):
    service = LeadService(db, workspace_id)
    return await service.add_lead(lead.dict())

@router.post("/{workspace_id}/trigger-prospecting")
async def trigger_prospecting(workspace_id: int):
    # In a real app, this would enqueue a job
    return {"status": "Prospecting job queued (mock)"}
