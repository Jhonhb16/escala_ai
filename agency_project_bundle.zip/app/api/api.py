from fastapi import APIRouter
from app.api.endpoints import leads, workspaces

api_router = APIRouter()
api_router.include_router(leads.router, prefix="/leads", tags=["leads"])
api_router.include_router(workspaces.router, prefix="/workspaces", tags=["workspaces"])
