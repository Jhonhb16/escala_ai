from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, JSON, Float, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class Workspace(Base):
    __tablename__ = "workspaces"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    api_keys = Column(JSON, default={}) # Encrypted storage in prod
    settings = Column(JSON, default={}) # Brand kit, rules, daily limits
    budget_limit = Column(Float, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    leads = relationship("Lead", back_populates="workspace")
    campaigns = relationship("Campaign", back_populates="workspace")

class Lead(Base):
    __tablename__ = "leads"

    id = Column(Integer, primary_key=True, index=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), nullable=False)
    
    search_term = Column(String, index=True)
    company_name = Column(String)
    website = Column(String)
    email = Column(String, index=True)
    phone = Column(String, nullable=True)
    city = Column(String)
    state = Column(String)
    
    status = Column(String, default="NEW") # NEW, QUALIFIED, DISQUALIFIED, CONTACTED
    quality_score = Column(Integer, default=0)
    
    metadata_info = Column(JSON, default={}) # Source data, scraping results
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    workspace = relationship("Workspace", back_populates="leads")

class Campaign(Base):
    __tablename__ = "campaigns"
    
    id = Column(Integer, primary_key=True, index=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), nullable=False)
    name = Column(String)
    status = Column(String, default="DRAFT") # DRAFT, ACTIVE, PAUSED, COMPLETED
    strategy_doc = Column(Text, nullable=True)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    workspace = relationship("Workspace", back_populates="campaigns")

class OutreachJob(Base):
    __tablename__ = "outreach_jobs"
    
    id = Column(Integer, primary_key=True, index=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), nullable=False)
    lead_id = Column(Integer, ForeignKey("leads.id"))
    
    job_type = Column(String) # EMAIL_GENERATION, SEND_EMAIL, CHECK_REPLY
    status = Column(String, default="PENDING") # PENDING, PROCESSING, COMPLETED, FAILED, BLOCKED_BY_QA
    
    payload = Column(JSON, default={}) # Email body, subject, etc.
    result = Column(JSON, default={}) # API response, error message
    
    scheduled_at = Column(DateTime(timezone=True), server_default=func.now())
    processed_at = Column(DateTime(timezone=True), nullable=True)

class AgentLog(Base):
    __tablename__ = "agent_logs"
    
    id = Column(Integer, primary_key=True)
    workspace_id = Column(Integer, ForeignKey("workspaces.id"), nullable=False)
    agent_name = Column(String)
    action = Column(String)
    details = Column(JSON)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
