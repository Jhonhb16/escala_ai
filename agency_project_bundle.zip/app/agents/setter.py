from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.state import AgentState
from app.tools.email_platform import EmailPlatform

class AppointmentSetterAgent(BaseAgent):
    def __init__(self, name: str = "Setter"):
        super().__init__(name, "Handles email responses and schedules meetings.")
        self.email_platform = EmailPlatform()

    def invoke(self, state: AgentState) -> Dict[str, Any]:
        """
        Checks for replies and books.
        """
        lead = state.get("current_lead")
        if not lead:
             return {"messages": ["Setter: No lead active."]}
        
        if lead["status"] == "CONTACTED":
            # Check for replies
            replies = self.email_platform.check_replies()
            # For mock, we can simulate a reply based on random chance or just manual triggering
            # For this MVP, let's assume if it's CONTACTED, we might get a reply in a batch run
            
            # Simple simulation: 20% chance of reply
            import random
            if random.random() < 0.2:
                 self.logger.info(f"Reply received from {lead['name']}!")
                 lead["status"] = "BOOKED"
                 return {
                    "current_lead": lead,
                    "messages": [f"Setter: Lead replied! Booking link sent."],
                    "metrics": {"leads_processed": 1}
                 }
            else:
                 self.logger.info(f"No reply yet from {lead['name']}")
                 return {"messages": ["Setter: No reply yet."]}

        return {"messages": ["Setter: Lead not in CONTACTED state, nothing to do."]}
