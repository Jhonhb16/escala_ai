from langchain_core.messages import HumanMessage, SystemMessage
from app.core.state import AgentState
from app.agents.base_team import prospect_node, qa_content_node, outreach_node
from typing import Literal

def supervisor_node(state: AgentState) -> dict:
    messages = state.get("messages", [])
    last_message = messages[-1] if messages else None
    
    # Simple state machine for the Base Team
    # Prospect -> Generate Content -> QA -> Finish
    
    if "Found" in last_message.content and "leads" in last_message.content:
        return {"next": "Outreach"}
        
    if "Generated" in last_message.content and "email drafts" in last_message.content:
        return {"next": "QA"}
        
    if "QA Complete" in last_message.content:
        return {"next": "__end__"}
        
    # Default start
    return {"next": "Prospector"}
