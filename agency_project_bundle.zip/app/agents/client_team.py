from langchain_core.messages import AIMessage, HumanMessage
from langgraph.graph import StateGraph, END
from app.core.state import AgentState
from app.core.llm import get_llm

async def strategist_node(state: AgentState):
    """
    Analyzes client data and proposes a strategy using Gemini.
    """
    workspace_id = state.get("workspace_id")
    print(f"--- STRATEGIST (Workspace {workspace_id}) ---")
    
    llm = get_llm(temperature=0.7)
    # in real app, fetch client niche/goals from DB
    niche = "Medical Spa"
    
    prompt = f"""
    Act as a Senior Marketing Strategist for a high-end {niche} in the USA.
    
    Task: Develop a Q1 Growth Strategy.
    Target Audience: Women 35-55, high disposable income.
    Key Treatment Focus: High-ticket non-invasive procedures (e.g., Morpheus8, CoolSculpting).
    
    Output Format: 
    Provide a concise Markdown bulleted list covering:
    1. Core Offer / Hook
    2. Primary Channel (Meta/Google)
    3. Content Angle (Educational vs Aesthetic)
    4. Follow-up sequence strategy
    """
    
    response = await llm.ainvoke([HumanMessage(content=prompt)])
    strategy = response.content
    
    return {
        "messages": [AIMessage(content=f"Strategy: {strategy}")],
        "shared_data": {"strategy": strategy},
        "next": "FunnelArchitect"
    }

async def funnel_node(state: AgentState):
    print("--- FUNNEL ARCHITECT ---")
    llm = get_llm(temperature=0.5)
    strategy = state.get("shared_data", {}).get("strategy", "")
    
    prompt = f"""
    Based on this strategy:
    {strategy}
    
    Design a 3-step marketing funnel (Ad -> Landing Page -> Conversion).
    Describe each step briefly.
    """
    
    response = await llm.ainvoke([HumanMessage(content=prompt)])
    funnel = response.content
    
    return {
        "messages": [AIMessage(content=f"Funnel Designed: {funnel}")],
        "shared_data": {"funnel": funnel},
        "next": "CreativeDirector"
    }

async def creative_node(state: AgentState):
    print("--- CREATIVE DIRECTOR ---")
    llm = get_llm(temperature=0.9)
    funnel = state.get("shared_data", {}).get("funnel", "")
    
    prompt = f"""
    Based on this funnel:
    {funnel}
    
    Generate 3 distinct image prompts for the Ad Creatives.
    Format as a list.
    """
    
    response = await llm.ainvoke([HumanMessage(content=prompt)])
    prompts = response.content
    
    return {
        "messages": [AIMessage(content=f"Generated image prompts: {prompts}")],
        "shared_data": {"image_prompts": prompts},
        "next": "__end__"
    }

def create_client_team_graph():
    workflow = StateGraph(AgentState)
    
    workflow.add_node("Strategist", strategist_node)
    workflow.add_node("FunnelArchitect", funnel_node)
    workflow.add_node("CreativeDirector", creative_node)
    
    workflow.set_entry_point("Strategist")
    
    workflow.add_edge("Strategist", "FunnelArchitect")
    workflow.add_edge("FunnelArchitect", "CreativeDirector")
    workflow.add_edge("CreativeDirector", END)
    
    return workflow.compile()
