from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.state import AgentState, Lead
from app.tools.openai_client import OpenAIClient
from app.tools.lead_sources import LeadSource
import json

class ProspectorAgent(BaseAgent):
    def __init__(self, name: str = "Prospector"):
        super().__init__(name, "Finds esthetic clinics and scores them.")
        self.client = OpenAIClient()
        self.lead_source = LeadSource()

    def invoke(self, state: AgentState) -> Dict[str, Any]:
        """
        Prospecting logic.
        """
        # Check if we have leads in queue
        queue = state.get("leads_queue", [])
        
        if not queue and not state.get("current_lead"):
            # Fetch new leads
            self.logger.info("Fetching new leads from source...")
            new_leads = self.lead_source.fetch_leads(count=5)
            queue.extend(new_leads)
            
        if not state.get("current_lead") and queue:
            # Pop next lead
            current_lead = queue.pop(0)
            self.logger.info(f"Processing lead: {current_lead['name']}")
            
            # Score Lead
            scored_lead = self._score_lead(current_lead)
            
            return {
                "current_lead": scored_lead,
                "leads_queue": queue,
                "messages": [f"Prospector: Found and scored {scored_lead['name']} ({scored_lead['score']}/100)"]
            }
            
        return {"messages": ["Prospector: No new leads or busy."]}

    def _score_lead(self, lead: Lead) -> Lead:
        """
        Uses Custom OpenAI Client to score.
        """
        prompt = [
            {"role": "system", "content": "Score the lead 0-100 based on fit for an esthetic marketing agency. "
                                          "High score for Botox/Fillers + US location. Return JSON: {\"score\": int}"},
            {"role": "user", "content": f"Lead: {json.dumps(lead, default=str)}"}
        ]
        
        try:
            response = self.client.chat_completion(prompt, json_mode=True)
            result = json.loads(response)
            score = result.get("score", 0)
        except Exception as e:
            self.logger.error(f"Scoring failed: {e}")
            score = 50 # Default
        
        lead["score"] = score
        if score > 70:
            lead["status"] = "QUALIFIED"
        else:
            lead["status"] = "REJECTED" # Mark low scores as rejected to filter them out
            
        return lead
