from langgraph.graph import StateGraph, END
from app.core.state import AgentState
from app.agents.base_team import prospect_node, outreach_node, qa_content_node
from app.agents.supervisor import supervisor_node

def create_base_team_graph():
    workflow = StateGraph(AgentState)
    
    workflow.add_node("Supervisor", supervisor_node)
    workflow.add_node("Prospector", prospect_node)
    workflow.add_node("Outreach", outreach_node)
    workflow.add_node("QA", qa_content_node)
    
    workflow.set_entry_point("Supervisor")
    
    workflow.add_edge("Prospector", "Supervisor")
    workflow.add_edge("Outreach", "Supervisor")
    workflow.add_edge("QA", "Supervisor")
    
    workflow.add_conditional_edges(
        "Supervisor",
        lambda x: x["next"],
        {
            "Prospector": "Prospector",
            "Outreach": "Outreach",
            "QA": "QA",
            "__end__": END
        }
    )
    
    return workflow.compile()
