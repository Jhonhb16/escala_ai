from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.state import AgentState
from app.tools.openai_client import OpenAIClient
from app.tools.email_platform import EmailPlatform

class ProposalBuilderAgent(BaseAgent):
    def __init__(self, name: str = "ProposalBuilder"):
        super().__init__(name, "Creates tailored proposals for booked leads.")
        self.client = OpenAIClient()
        self.email_platform = EmailPlatform()

    def invoke(self, state: AgentState) -> Dict[str, Any]:
        """
        Generates a proposal for booked leads.
        """
        lead = state.get("current_lead")
        if not lead or lead["status"] != "BOOKED":
            return {"messages": ["Proposal: Lead not ready for proposal."]}

        self.logger.info(f"Generating proposal for {lead['name']}...")
        
        prompt = [
            {"role": "system", "content": "Create a proposal executive summary for an esthetic clinic. Price: $1500/mo."},
            {"role": "user", "content": f"Client: {lead['name']}\nLocation: {lead['location']}"}
        ]
        
        proposal_content = self.client.chat_completion(prompt)
        
        # Send proposal email
        self.email_platform.send_email(lead["email"], "Your Custom Proposal", proposal_content)
        
        # Save Intake Data
        import json
        import os
        from app.core.config import Config

        intake_data = {
            "clinic_name": lead["name"],
            "pain_points": "Needs more qualified patient bookings.", # Heuristic
            "promise_sold": "30 Qualified Appointments in 90 Days",
            "budget_estimated": "$1500/mo",
            "notes": lead["notes"]
        }

        intake_file = os.path.join(Config.OUTPUT_DIR, "client_intake.json")
        try:
            existing_data = []
            if os.path.exists(intake_file):
                with open(intake_file, 'r', encoding='utf-8') as f:
                    existing_data = json.load(f)
            
            existing_data.append(intake_data)
            
            with open(intake_file, 'w', encoding='utf-8') as f:
                json.dump(existing_data, f, indent=2)
            self.logger.info(f"Client Intake Saved to {intake_file}")
        except Exception as e:
            self.logger.error(f"Failed to save intake: {e}")

        updated_lead = {**lead, "notes": lead["notes"] + f"\n[Proposal Sent]: {proposal_content}", "status": "CLOSED_WON"}

        return {
             "messages": [f"Proposal Sent and Intake Saved for {lead['name']}"],
             "current_lead": updated_lead,
             "metrics": {"leads_processed": 1}
        }
