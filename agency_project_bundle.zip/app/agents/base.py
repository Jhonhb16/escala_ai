from abc import ABC, abstractmethod
from typing import Any, Dict, List
from langchain_core.messages import BaseMessage
from app.core.state import AgentState
from app.core.logger import get_logger

logger = get_logger("BaseAgent")

class BaseAgent(ABC):
    def __init__(self, name: str, instructions: str):
        self.name = name
        self.instructions = instructions
        self.logger = logger.bind(agent=name)

    @abstractmethod
    def invoke(self, state: AgentState) -> Dict[str, Any]:
        """
        Execute the agent's logic.
        Must return a dictionary that updates the State.
        """
        pass

    def get_instructions(self) -> str:
        return self.instructions
