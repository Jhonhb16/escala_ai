from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from app.core.state import AgentState
from app.core.compliance import ComplianceEngine
from app.services.lead_service import LeadService
from app.core.database import AsyncSessionLocal
from app.services.integrations import ApolloClient
from app.core.llm import get_llm
import json

# Real Prospector with Apollo
async def prospect_node(state: AgentState):
    """
    Finds leads using Apollo.io and saves them to the DB.
    """
    workspace_id = state.get("workspace_id")
    print(f"--- PROSPECTOR (Workspace {workspace_id}) ---")
    
    # 1. Determine search criteria
    # In a full agent, we might use LLM to parse "Med Spas in Miami" from state messages
    # For now, default to "Med Spa Owner"
    search_term = "Med Spa" 
    
    apollo = ApolloClient()
    new_leads_data = await apollo.search_leads(search_term, limit=5)
    await apollo.close()
    
    saved_leads = []
    
    if workspace_id:
        async with AsyncSessionLocal() as session:
            service = LeadService(session, workspace_id)
            for lead_data in new_leads_data:
                # Add default status
                lead_data["status"] = "NEW"
                # Ensure validation
                if not lead_data.get("email"):
                    continue
                    
                try:
                    lead = await service.add_lead(lead_data)
                    saved_leads.append(lead)
                except Exception as e:
                    print(f"Error saving lead: {e}")
    else:
        saved_leads = new_leads_data 
    
    return {
        "messages": [AIMessage(content=f"Found and saved {len(saved_leads)} new leads from Apollo.")],
        "shared_data": {"new_leads": [l.__dict__ if hasattr(l, '__dict__') else l for l in saved_leads]},
        "next": "Outreach"
    }

# Outreach Generator with Gemini
async def outreach_node(state: AgentState):
    """
    Generates email content using Gemini.
    """
    print("--- OUTREACH ---")
    leads = state.get("shared_data", {}).get("new_leads", [])
    if not leads:
        return {"messages": [AIMessage(content="No leads to process.")], "next": "Supervisor"}
    
    llm = get_llm(temperature=0.7)
    generated_emails = []
    
    for lead in leads:
        company = lead.get("company_name", "your clinic") if isinstance(lead, dict) else lead.company_name or "your clinic"
        city = lead.get("city", "USA") if isinstance(lead, dict) else lead.city or "USA"
        title = lead.get("title", "Owner") if isinstance(lead, dict) else lead.title or "Owner"
        
        prompt = f"""
        You are an expert medical marketing outreach specialist acting on behalf of an agency.
        Write a hyper-personalized cold email to {title} at {company} in {city}.
        
        GOAL: Book a 15-min discovery call to discuss AI automation for their clinic.
        
        CONSTRAINTS:
        - STRICTLY FORBIDDEN: Words like "cure", "guarantee", "results in 24h", "medical advice".
        - Tone: Professional, respectful, B2B. Not salesy.
        - Structure: 
          1. Observation about their city/clinic.
          2. Pain point (missed leads, admin load).
          3. Solution (AI reception/booking).
          4. Soft Call to Action (CTA).
        - Length: Under 150 words.
        
        OUTPUT FORMAT:
        Return ONLY valid JSON with keys: "subject", "body".
        Example: {{"subject": "Quick question...", "body": "Hi..."}}
        """
        
        try:
            response = await llm.ainvoke([HumanMessage(content=prompt)])
            # Robust JSON cleaning
            content = response.content.replace("```json", "").replace("```", "").strip()
            start = content.find("{")
            end = content.rfind("}") + 1
            
            if start != -1 and end != -1:
                json_str = content[start:end]
                email_data = json.loads(json_str)
            else:
                # Fallback if LLM fails strict JSON
                email_data = {"subject": f"Growth for {company}", "body": content}
                
            generated_emails.append({
                "company": company,
                "subject": email_data.get("subject"),
                "body": email_data.get("body")
            })
        except json.JSONDecodeError:
            print(f"JSON Parse Error for {company}. Raw: {response.content[:50]}...")
            generated_emails.append({
                "company": company,
                "subject": f"Opportunity for {company}",
                "body": response.content  # Use raw content if JSON fails but content is there
            })
        except Exception as e:
            print(f"LLM Error: {e}")
            generated_emails.append({
                "company": company, 
                "subject": "Error", 
                "body": "Error generating email due to API issue."
            })
        
    return {
        "messages": [AIMessage(content=f"Generated {len(generated_emails)} email drafts using Gemini.")],
        "shared_data": {"generated_emails": generated_emails},
        "next": "QA"
    }

# QA Node (Compliance Engine is good, but let's make it async compliant if needed, currently sync)
async def qa_content_node(state: AgentState):
    # ... (same as before, just ensuring imports)
    print("--- QA CONTENT ---")
    emails = state.get("shared_data", {}).get("generated_emails", [])
    approved_emails = []
    
    for email in emails:
        passed, issues, suggestion = ComplianceEngine.check_text(email["body"])
        if passed:
            email["status"] = "APPROVED"
            approved_emails.append(email)
        else:
            email["status"] = "REJECTED"
            email["issues"] = issues
            
    return {
        "messages": [AIMessage(content=f"QA Complete. Approved: {len(approved_emails)}/{len(emails)}")],
        "shared_data": {"approved_emails": approved_emails},
        "next": "Supervisor"
    }
