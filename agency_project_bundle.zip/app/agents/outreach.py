from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.state import AgentState
from app.tools.openai_client import OpenAIClient
from app.tools.email_platform import EmailPlatform
from app.tools.compliance import ComplianceGate

class OutreachAgent(BaseAgent):
    def __init__(self, name: str = "Outreach"):
        super().__init__(name, "Drafts and sends cold emails.")
        self.client = OpenAIClient()
        self.email_platform = EmailPlatform()
        self.compliance = ComplianceGate()

    def invoke(self, state: AgentState) -> Dict[str, Any]:
        """
        Drafts and sends email if compliant.
        """
        lead = state.get("current_lead")
        if not lead or lead["status"] != "QUALIFIED":
            return {"messages": ["Outreach: No qualified lead to contact."]}

        self.logger.info(f"Drafting email for {lead['name']}...")
        
        prompt = [
            {"role": "system", "content": "Write a short, personalized cold email to the clinic. "
                                          "Focus on their services (Botox/Fillers). "
                                          "Do NOT be salesy. Ask availability."},
            {"role": "user", "content": f"Lead Name: {lead['name']}\nServices: {lead['services']}\nLocation: {lead['location']}"}
        ]
        
        email_content = self.client.chat_completion(prompt)
        
        # Compliance Check
        if not self.compliance.review_content(email_content):
            lead["notes"] += "\n[Outreach]: Content Rejected by Compliance."
            return {
                "messages": ["Outreach: Draft rejected by compliance."],
                "current_lead": lead,
                "errors": ["Compliance Violation"]
            }
            
        # Send Email
        self.email_platform.send_email(lead["email"], "Partnership Opportunity", email_content)
        
        return {
            "messages": [f"Outreach: Email Sent to {lead['name']}"],
            "current_lead": {**lead, "status": "CONTACTED", "notes": lead["notes"] + f"\n[Email Sent]: {email_content}"},
            "metrics": {"emails_sent_today": 1} # This logic needs to aggregate, but LangGraph merge handles dict updates? No, it usually replaces.
            # We need to handle metrics update carefully in the reducer or just pass the delta.
            # For this simple prototype, we'll assume the reducer adds them or we just track locally.
            # The State definition uses `operator.add` for messages but not for metrics.
            # We should probably update the State definition to handle metrics aggregation if we want robust tracking in State.
            # For now, let's just return the message.
        }
