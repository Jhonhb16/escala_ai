from app.agents.graph import create_base_team_graph
from app.agents.client_team import create_client_team_graph

class AgentFactory:
    @staticmethod
    def get_base_team():
        return create_base_team_graph()
    
    @staticmethod
    def get_client_team(workspace_id: int):
        # In the future, we could load custom weights/config per workspace
        return create_client_team_graph()
