from typing import Any, Dict
from app.agents.base import BaseAgent
from app.core.state import AgentState
from app.tools.compliance import ComplianceGate

class ComplianceAgent(BaseAgent):
    def __init__(self, name: str = "Compliance"):
        super().__init__(name, "Reviews content for safety and medical compliance.")
        self.gate = ComplianceGate()

    def invoke(self, state: AgentState) -> Dict[str, Any]:
        """
        Standalone compliance check if triggered by Supervisor.
        """
        # specialized usage: check the last message content
        messages = state.get("messages", [])
        if not messages:
            return {"messages": ["Compliance: No content to review."]}
            
        last_msg = messages[-1].content
        
        is_safe = self.gate.review_content(last_msg, context="General Check")
        
        if is_safe:
            return {"messages": ["Compliance: Content Approved."]}
        else:
            return {
                "messages": ["Compliance: Content REJECTED."],
                "errors": ["Compliance Violation detected in last message."]
            }
