import shutil
import os
import zipfile

def create_bundle():
    source_dir = os.getcwd()
    output_filename = "agency_project_bundle.zip"
    
    # Define exclusions
    exclusions = {'.venv', '.venv_clean', 'venv', '.git', '__pycache__', '.idea', '.vscode', 'node_modules'}
    
    print(f"Zipping project to {output_filename}...")
    
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            # Modify dirs in-place to skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclusions]
            
            for file in files:
                if file == output_filename:
                    continue
                if file.endswith('.pyc') or file.endswith('.log'):
                    continue
                    
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, source_dir)
                zipf.write(file_path, arcname)
                
    print(f"Created: {os.path.abspath(output_filename)}")

if __name__ == "__main__":
    create_bundle()
