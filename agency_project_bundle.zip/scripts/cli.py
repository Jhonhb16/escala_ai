import typer
import asyncio
import sys
import os
# Add project root to path
sys.path.append(os.getcwd())

from typing import Optional
from rich.console import Console
from app.core.database import AsyncSessionLocal
from app.services.workspace_service import WorkspaceService
from app.services.lead_service import LeadService
from app.agents.factory import AgentFactory

app = typer.Typer()
console = Console()

async def create_workspace_async(name: str):
    try:
        async with AsyncSessionLocal() as db:
            service = WorkspaceService(db)
            ws = await service.create_workspace(name)
            console.print(f"[green]Created workspace: {ws.name} (ID: {ws.id})[/green]")
    except Exception as e:
        console.print(f"[red]Error creating workspace: {e}[/red]")

@app.command()
def create_workspace(name: str):
    """Create a new client workspace."""
    asyncio.run(create_workspace_async(name))

async def ingest_leads_async(workspace_id: int, count: int):
    try:
        async with AsyncSessionLocal() as db:
            service = LeadService(db, workspace_id)
            for i in range(count):
                await service.add_lead({
                    "company_name": f"Clinic {i}",
                    "email": f"clinic{i}@example.com",
                    "city": "Miami",
                    "status": "NEW"
                })
            console.print(f"[green]Ingested {count} leads for workspace {workspace_id}[/green]")
    except Exception as e:
        console.print(f"[red]Error ingesting leads: {e}[/red]")

@app.command()
def ingest_leads(workspace_id: int, count: int = 5):
    """Ingest mock leads for a workspace."""
    asyncio.run(ingest_leads_async(workspace_id, count))

async def run_outreach_async(workspace_id: int):
    console.print(f"[bold blue]Running Outreach Agent for Workspace {workspace_id}...[/bold blue]")
    try:
        graph = AgentFactory.get_base_team()
        
        initial_state = {
            "messages": [],
            "workspace_id": workspace_id,
            "shared_data": {},
            "metrics": {},
            "next": "Prospector"
        }
        
        step_count = 0
        max_steps = 20
        
        async for event in graph.astream(initial_state):
            step_count += 1
            if step_count > max_steps:
                console.print("[red]Max steps reached. Stopping loop.[/red]")
                break
                
            for k, v in event.items():
                if k != "__end__":
                    console.print(f"[yellow]--- Node Finished: {k} ---[/yellow]")
                    
                    if "messages" in v and v["messages"]:
                        last_msg = v['messages'][-1]
                        # Clean content print
                        content = last_msg.content.replace("\n", " ")[:150]
                        console.print(f"[dim]Msg:[/dim] {content}...")
                        
                    if k == "Prospector" and "shared_data" in v:
                        leads = v["shared_data"].get("new_leads", [])
                        console.print(f"[cyan] Found {len(leads)} leads[/cyan]")
                        
                    if k == "Outreach" and "shared_data" in v:
                        emails = v["shared_data"].get("generated_emails", [])
                        console.print(f"[green] Generated {len(emails)} emails[/green]")
                        
                    if k == "QA" and "shared_data" in v:
                        approved = v["shared_data"].get("approved_emails", [])
                        console.print(f"[bold green] QA Approved: {len(approved)} emails[/bold green]")

    except Exception as e:
        console.print(f"[red]CRITICAL ERROR running outreach: {e}[/red]")
        import traceback
        traceback.print_exc()

@app.command()
def run_outreach(workspace_id: int):
    """Run the outreach agent flow for a workspace."""
    asyncio.run(run_outreach_async(workspace_id))

if __name__ == "__main__":
    app()
