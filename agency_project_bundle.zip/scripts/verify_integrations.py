import asyncio
import sys
import os
# Add project root to path
sys.path.append(os.getcwd())

from app.core.config import settings
from app.core.llm import get_llm
from app.services.integrations import ApolloClient
from langchain_core.messages import HumanMessage

async def check_llm():
    print("Checking LLM (Gemini)...")
    try:
        llm = get_llm()
        response = await llm.ainvoke([HumanMessage(content="Say 'Hello World' if you are working.")])
        print(f"LLM Response: {response.content}")
        return True
    except Exception as e:
        print(f"LLM Failed: {e}")
        return False

async def check_apollo():
    print("Checking Apollo API...")
    try:
        client = ApolloClient()
        results = await client.search_leads("Med Spa", limit=1)
        await client.close()
        if results:
            print(f"Apollo Success: Found {len(results)} leads. First: {results[0].get('company_name')}")
            return True
        else:
            print("Apollo: No leads found (Check key or query)")
            return True # Not necessarily failure, just no results
    except Exception as e:
        print(f"Apollo Failed: {e}")
        return False

async def main():
    print(f"Environment: {settings.ENVIRONMENT}")
    print(f"Gemini Key: {'*' * 5}{settings.GEMINI_API_KEY[-4:] if settings.GEMINI_API_KEY else 'NONE'}")
    print(f"Apollo Key: {'*' * 5}{settings.APOLLO_API_KEY[-4:] if settings.APOLLO_API_KEY else 'NONE'}")
    
    llm_ok = await check_llm()
    apollo_ok = await check_apollo()
    
    if llm_ok and apollo_ok:
        print("\n>>> ALL CHECKS PASSED <<<")
    else:
        print("\n>>> SOME CHECKS FAILED <<<")

if __name__ == "__main__":
    asyncio.run(main())
