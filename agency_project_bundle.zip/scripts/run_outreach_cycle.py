import sys
import os
import argparse
from langchain_core.messages import HumanMessage
from dotenv import load_dotenv

sys.path.append(os.getcwd())

from app.flows.main_flow import create_flow
from app.core.logger import get_logger

load_dotenv()
logger = get_logger("OutreachCycle")

def run_outreach():
    logger.info("Starting Outreach Cycle (Reply Check + Queue Processing)...")
    
    # 1. Always check for replies first
    try:
        from app.tools.email_platform import EmailPlatform
        platform = EmailPlatform()
        replies = platform.check_replies()
        logger.info(f"Checked for replies. Found: {len(replies)}")
    except Exception as e:
        logger.error(f"Failed to check replies: {e}")

    # 2. Check Queue
    # In a real app, this would query the DB.
    # For now, we mock an empty queue to show safety.
    initial_queue = [] 
    
    if not initial_queue:
        logger.info("Lead queue is empty. Logic prevents falling back to Prospecting. Exiting cycle.")
        return

    app = create_flow()

    initial_state = {
        "messages": [HumanMessage(content="Process the leads in the queue.")],
        "leads_queue": initial_queue, 
        "metrics": {"emails_sent_today": 0, "tokens_used": 0, "leads_processed": 0},
        "errors": []
    }
    
    try:
        # We add a recursion limit or a check to ensure we don't loop forever
        step_count = 0
        MAX_STEPS = 10
        
        for event in app.stream(initial_state):
            step_count += 1
            if step_count >= MAX_STEPS:
                logger.warning("Max steps reached in Outreach Cycle. Force stopping.")
                break
            pass 
            
        logger.info("Outreach Cycle Completed.")
        
    except Exception as e:
        logger.error(f"Outreach Failed: {e}")

if __name__ == "__main__":
    run_outreach()
