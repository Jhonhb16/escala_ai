import sys
import os
import argparse
import json
import csv
import re
from langgraph.graph import END
from langchain_core.messages import HumanMessage
from dotenv import load_dotenv

# Ensure app is in path
sys.path.append(os.getcwd())

from app.flows.main_flow import create_flow
from app.core.logger import get_logger
from app.core.config import Config

load_dotenv()
logger = get_logger("BatchProspect")

def save_json(data, filename):
    filepath = os.path.join(Config.OUTPUT_DIR, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    logger.info(f"Saved {filename} to {filepath}")

def save_csv(data, filename, fieldnames):
    filepath = os.path.join(Config.OUTPUT_DIR, filename)
    with open(filepath, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)
    logger.info(f"Saved {filename} to {filepath}")

def extract_first_name(name, email):
    # Try to get first name from email (e.g., sarah@...)
    if email:
        user_part = email.split('@')[0]
        if '.' in user_part:
            return user_part.split('.')[0].title()
        return user_part.title()
    # Fallback to name
    return name.split(' ')[0] if name else "Hi"

def extract_personalization(notes):
    # Try to find the email content in notes
    # Notes usually format: ...\n[Email Sent]: Subject: ...\n\nHi Name,\n\nPersonalization...
    match = re.search(r"\[Email Sent\]:.*?\n\n(.*?)(?=\n)", notes, re.DOTALL)
    if match:
        line = match.group(1).strip()
        # Clean up commonly occurring greetings if captured
        line = re.sub(r"^(Hi|Hello|Dear)\s+.*?,?\s*", "", line, flags=re.IGNORECASE)
        return line[:150] # Limit length
    return "Saw your great work in the area."

def run_prospecting(count: int = 5):
    if count > 50:
        logger.warning(f"Count {count} exceeds limit of 50. Capping at 50.")
        count = 50

    logger.info(f"Starting Prospecting for {count} leads...")
    
    app = create_flow()
    
    initial_message = f"Find {count} new leads, score them, and if qualified, draft an outreach email."
    
    initial_state = {
        "messages": [HumanMessage(content=initial_message)],
        "leads_queue": [],
        "metrics": {"emails_sent_today": 0, "tokens_used": 0, "leads_processed": 0},
        "errors": []
    }
    
    processed_leads = {}
    step_count = 0
    max_steps = count * 7 # Heuristic limit
    
    try:
        for event in app.stream(initial_state):
            step_count += 1
            
            # Capture updated lead state
            for node_name, updates in event.items():
                if node_name == "__end__": 
                    continue
                
                if "current_lead" in updates and updates["current_lead"]:
                    lead = updates["current_lead"]
                    processed_leads[lead["id"]] = lead
            
            if step_count >= max_steps:
                logger.warning("Max steps reached. Process might be incomplete.")
                break
                
        logger.info("Batch Run Completed. Generating exports...")
        
        # Prepare exports
        all_leads = list(processed_leads.values())
        emails_drafted = [l for l in all_leads if "CONTACTED" in l.get("status", "")]
        
        # 1. Leads Scored
        save_json(all_leads, "leads_scored.json")
        
        # 2. Emails Drafted
        save_json(emails_drafted, "emails_drafted.json")
        
        # 3. Instantly CSV
        instantly_rows = []
        for l in emails_drafted:
            instantly_rows.append({
                "email": l.get("email"),
                "first_name": extract_first_name(l.get("name"), l.get("email")),
                "company": l.get("name"),
                "website": l.get("website"),
                "personalization_line": extract_personalization(l.get("notes", ""))
            })
            
        save_csv(instantly_rows, "instantly_upload.csv", ["email", "first_name", "company", "website", "personalization_line"])
        
    except Exception as e:
        logger.error(f"Execution Failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=5, help="Number of leads to process")
    args = parser.parse_args()
    
    run_prospecting(args.count)
