#!/bin/bash
set -e

echo "Starting VPS Setup..."

# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo apt-get install -y docker-compose-plugin

# Setup directories
mkdir -p /opt/agency-ai/app
mkdir -p /opt/agency-ai/data

# Permissions
# Allow current user to run docker without sudo
sudo usermod -aG docker $USER

echo "VPS Setup Complete!"
echo "1. Upload project files to /opt/agency-ai/app"
echo "2. Rename .env.example to .env and fill in keys"
echo "3. Run: docker compose up -d --build"

