#!/bin/bash
set -e

echo "Running Smoke Tests..."

# Ensure DB is up (in separate terminal or background)
# python -m app.main & 

# 1. Create Workspace
python scripts/cli.py create-workspace "SmokeTestClinic"

# 2. Ingest Leads
python scripts/cli.py ingest-leads 1 5

# 3. Run Outreach
python scripts/cli.py run-outreach 1

echo "Smoke Tests Complete!"
